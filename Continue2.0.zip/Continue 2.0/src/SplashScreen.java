import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

public class SplashScreen extends  JFrame{    
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JProgressBar jb;    
	int i=0,num=0;     
		SplashScreen()
	{
	setIconImage(Toolkit.getDefaultToolkit().getImage("d:\\Users\\Imran\\Desktop\\img\\icon.png"));
	setFont(new Font("Dialog", Font.PLAIN, 15));
	getContentPane().setBackground(Color.WHITE);
	setUndecorated(true);
	setSize(1020,607);    
	getContentPane().setLayout(null); 
	
	Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    
    
    //ImageIcon img = new ImageIcon("contineo.png");  
    JLabel lblNewLabel = new JLabel(" ",new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\contineo.png"),SwingConstants.CENTER);

	lblNewLabel.setBounds(188, 189, 604, 176);
	getContentPane().add(lblNewLabel);
	
	
	
	jb=new JProgressBar(0,100);
	jb.setBounds(0, 585, 1020, 22);
	getContentPane().add(jb);
	jb.setForeground(Color.RED);
	jb.setValue(0);    
	jb.setStringPainted(true);
	
	ImageIcon img3 = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\splashimage.png").getImage().getScaledInstance(1034,658, Image.SCALE_SMOOTH));
	
	JLabel lblNewLabel_2 = new JLabel(" ",img3,JLabel.CENTER);
	lblNewLabel_2.setBounds(0, 0, 1034, 658);
	getContentPane().add(lblNewLabel_2);
	}    
	public void iterate(){    
	while(i<=100){    
		  jb.setForeground(Color.green);
	  jb.setValue(i);    
	  i=i+2;
//	  if(i==34)
//		  jb.setForeground(Color.orange);
//	  if(i==66)
//		  jb.setForeground(Color.green);
	  if(i==100) {
		  jb.setForeground(Color.green);
		  try {
			  
			jb.setValue(100);
			Thread.sleep(50);
			this.dispose();
			UserType lg = new UserType();
			lg.setVisible(true);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
		  
		  
	  }
	  try{Thread.sleep(150);}catch(Exception e){}    
	}    
	}    
	public static void main(String[] args) {    
		SplashScreen m=new SplashScreen();    
	    m.setVisible(true);    
	    m.iterate();    
	}    
	}    