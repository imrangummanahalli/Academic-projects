
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class AdminStudentDetails extends JFrame implements ActionListener{
 
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel l1,l2,l3;
    JTable t1;
    JButton b2,b3;
    JTextField t2;
    String x[] = {"Name","Father's Name","Age","Date of Birth","Address","Phone","Email","Usn","Class","Branch"};
    String y[][] = new String[20][13];
    int i=0, j=0;
    private JLabel lblStudentDetails;
    AdminStudentDetails()
    {
        super("Student Details");
        setIconImage(Toolkit.getDefaultToolkit().getImage("d:\\Users\\Imran\\Desktop\\img\\icon.png"));
        setUndecorated(true);
        setSize(1239,650);
        setLocation(200,200);
        getContentPane().setLayout(null);
        
    	
	     Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
  
        l1 = new JLabel("Enter USN to delete Student : ");
        l1.setBounds(39,416,400,30);
        l1.setFont(new Font("serif",Font.BOLD,20));
        getContentPane().add(l1);
        
        t2 = new JTextField();
        t2.setBounds(391,416,200,30);
        getContentPane().add(t2);
            
        l2 = new JLabel("Add New Student");
        l2.setBounds(39,508,400,30);
        l2.setFont(new Font("serif",Font.BOLD,20));
        getContentPane().add(l2);
        
        b2 = new JButton("Add Student");
        b2.setBackground(new Color(0, 102, 0));
        b2.setForeground(Color.WHITE);
        b2.setBounds(300, 508, 150 ,30);
        getContentPane().add(b2);
        
        l3 = new JLabel("Update Student Details");
        l3.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		dispose();
        		new AdminUpdateStudent().setVisible(true);
        	}
        });
        l3.setBounds(39,572,400,30);
        l3.setFont(new Font("serif",Font.BOLD,20));
        getContentPane().add(l3);
        
        b3 = new JButton("Update Student");
        b3.setBackground(new Color(0, 0, 153));
        b3.setForeground(Color.WHITE);
        b3.setBounds(300, 572, 150 ,30);
        getContentPane().add(b3);
        b2.addActionListener(this);
        b3.addActionListener(this);
        
        
        try{
        	Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/continue2.0","root", "");
            PreparedStatement st = (PreparedStatement) connection.prepareStatement("Select * from student");
          
           //String s1 = "select * from student";
           ResultSet rs  = st.executeQuery();
            while(rs.next()){
                y[i][j++]=rs.getString("name");
                y[i][j++]=rs.getString("fathers_name");
                y[i][j++]=rs.getString("age");
                y[i][j++]=rs.getString("dob");
                y[i][j++]=rs.getString("address");
                y[i][j++]=rs.getString("phone");
                y[i][j++]=rs.getString("email");
                y[i][j++]=rs.getString("usn");
                y[i][j++]=rs.getString("class");
                y[i][j++]=rs.getString("branch");
                i++;
                j=0;
            }
            t1 = new JTable(y,x);
            
        }catch(Exception e){
            e.printStackTrace();
        }
        JScrollPane sp = new JScrollPane(t1);
        sp.setBounds(29,61,1200,330);
        getContentPane().add(sp);
        
        getContentPane().setBackground(Color.WHITE);
        
        JButton btnNewButton = new JButton("Delete");
        btnNewButton.setBackground(new Color(153, 0, 0));
        btnNewButton.setForeground(Color.WHITE);
        //btnNewButton.setBounds(627, 381, 100 ,30);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 String usn = t2.getText();
                 // String password = passwordField.getText();
                  try {
                      Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/continue2.0","root", "");
                      PreparedStatement st = (PreparedStatement) connection.prepareStatement("delete from student where usn = '"+usn +"'");
                     // st.setString(1, usn);
                       PreparedStatement st1 = (PreparedStatement) connection.prepareStatement("Select usn from student where usn = '"+usn+"'");
                       ResultSet rs = st1.executeQuery();
                       int result = JOptionPane.showConfirmDialog(btnNewButton,"Sure? You want to Delete?", "Delete",
                               JOptionPane.YES_NO_OPTION,
                               JOptionPane.QUESTION_MESSAGE);
                       if(result == JOptionPane.YES_OPTION){
                    	   if(rs.next())
                             {
                            
                           if (usn.equals(rs.getString(1))) {
                         	  
                             //  dispose();
                         	  st.executeUpdate();
                               JOptionPane.showMessageDialog(btnNewButton, "successfully");
                               dispose();
                               new AdminStudentDetails().setVisible(true);
                           } 
                             }
                           else {
                               JOptionPane.showMessageDialog(btnNewButton, "Incorrect USN");
                           }

                        }
                      
                           
//                        if(rs.next())
//                        {
//                       
//                      if (usn.equals(rs.getString(1))) {
//                    	  
//                        //  dispose();
//                    	  st.executeUpdate();
//                          JOptionPane.showMessageDialog(btnNewButton, "successfully");
//                          new AdminStudentDetails().setVisible(true);
//                      } 
//                        }
//                      else {
//                          JOptionPane.showMessageDialog(btnNewButton, "Incorrect USN");
//                      }
                  } catch (SQLException sqlException) {
                      sqlException.printStackTrace();
                      JOptionPane.showMessageDialog(btnNewButton, "Check Your Database Connection");
                  }
        		
        	}
        });
        btnNewButton.setBounds(619, 416, 100 ,30);
        getContentPane().add(btnNewButton);
        
        JLabel lblNewLabel_2 = new JLabel("x");
        lblNewLabel_2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblNewLabel_2.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        	//dispose();
//            int result = JOptionPane.showConfirmDialog(btnNewButton,"Sure? You Will Be logged Out?", "Close",
//                    JOptionPane.YES_NO_OPTION,
//                    JOptionPane.QUESTION_MESSAGE);
//            if(result == JOptionPane.YES_OPTION){
            	dispose();
            	new AdminDashboard().setVisible(true);
            }
        
        });
        lblNewLabel_2.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_2.setForeground(Color.RED);
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 46));
        lblNewLabel_2.setBackground(Color.WHITE);
        lblNewLabel_2.setBounds(1203, -13, 36, 52);
        getContentPane().add(lblNewLabel_2);
        
        lblStudentDetails = new JLabel("Student Details");
        lblStudentDetails.setForeground(new Color(51, 204, 0));
        lblStudentDetails.setFont(new Font("Times New Roman", Font.BOLD, 29));
        lblStudentDetails.setBounds(522, 0, 252, 72);
        getContentPane().add(lblStudentDetails);
    }
  
    public static void main(String[] args){
        new AdminStudentDetails().setVisible(true);
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		dispose();
		new AdminAddStudent().setVisible(true);
		
	}
}
