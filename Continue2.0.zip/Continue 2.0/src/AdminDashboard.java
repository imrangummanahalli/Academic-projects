import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingConstants;
import javax.swing.Icon;
//import javax.swing.Icon;

public class AdminDashboard extends JFrame {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminDashboard frame = new AdminDashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminDashboard() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("d:\\Users\\Imran\\Desktop\\img\\icon.png"));
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 984, 615);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 425, 637);
		contentPane.add(panel);
		panel.setLayout(null);
		ImageIcon imgpass = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\LN.png").getImage().getScaledInstance(420,615,Image.SCALE_AREA_AVERAGING));
		JLabel lblNewLabel = new JLabel("",imgpass,JLabel.CENTER);
		lblNewLabel.setBounds(-10, 0, 425, 615);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(423, 0, 561, 615);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		 
		
		
        ImageIcon imguser = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\user.png").getImage().getScaledInstance(40, 40,Image.SCALE_AREA_AVERAGING));
		
		ImageIcon imgpass1 = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\pass.png").getImage().getScaledInstance(40, 40, Image.SCALE_AREA_AVERAGING));
		
		JLabel lblNewLabel_2 = new JLabel("x");
		lblNewLabel_2.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		panel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				AdminLogin f = new AdminLogin();
				f.setVisible(true);
			}
		});
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 46));
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setBounds(525, -14, 36, 52);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Select ");
		lblNewLabel_3.setForeground(new Color(25, 69, 107));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 23));
		 getContentPane().add(lblNewLabel_3,SwingConstants.CENTER);
		lblNewLabel_3.setBounds(262, 10, 78, 49);
		panel_1.add(lblNewLabel_3);
		
		
		
		 ImageIcon imgteacher = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\teacher.png").getImage().getScaledInstance(250, 250,Image.SCALE_AREA_AVERAGING));
			
		JLabel lblNewLabel_1 = new JLabel("",imgteacher,JLabel.CENTER);
		lblNewLabel_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			dispose();
			 new TeacherDetails().setVisible(true);
			}
		});
		lblNewLabel_1.setBounds(150, 69, 289, 279);
		panel_1.add(lblNewLabel_1);
		
		 ImageIcon imgstudent = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\student.png").getImage().getScaledInstance(250, 250,Image.SCALE_AREA_AVERAGING));
			
		
		JLabel lblNewLabel_1_1 = new JLabel("",imgstudent,JLabel.CENTER);
		lblNewLabel_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 dispose();
				 new StudentDetails().setVisible(true);
			}
		});
		lblNewLabel_1_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel_1_1.setBounds(150, 336, 289, 279);
		panel_1.add(lblNewLabel_1_1);
		
	
		
		
	     Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
	}
}