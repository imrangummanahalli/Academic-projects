import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Cursor;
import com.toedter.calendar.JDateChooser;

public class UpdateTeacher extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_5;
	private JTextField textField_7;
	private JTextField textField_8;
	private JLabel id1_6_1_2;
	private JLabel lblNewLabel;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateTeacher frame = new UpdateTeacher();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateTeacher() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\Users\\Imran\\Desktop\\img\\icon.png"));
		setUndecorated(true);
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 973, 631);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel id8 = new JLabel("Update Teacher Details");
		id8.setForeground(new Color(51, 204, 0));
		id8.setFont(new Font("Times New Roman", Font.BOLD, 29));
		id8.setBounds(329, 10, 356, 74);
		contentPane.add(id8);
		
		JLabel id1 = new JLabel("Name");
		id1.setFont(new Font("Serif", Font.BOLD, 20));
		id1.setBounds(81, 163, 100, 30);
		contentPane.add(id1);
		
		textField = new JTextField();
		textField.setBounds(210, 168, 149, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(210, 227, 149, 30);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(210, 293, 149, 30);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(210, 359, 149, 30);
		contentPane.add(textField_3);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(667, 168, 149, 30);
		contentPane.add(textField_5);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(667, 293, 149, 30);
		textField_7.setEditable(false);
		contentPane.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(667, 359, 149, 30);
		contentPane.add(textField_8);
		JDateChooser date = new JDateChooser();
		date.setBounds(667, 227, 149, 30);
		contentPane.add(date);
		
		String course[] = {"B.Tech","BBA","BCA","Bsc","Msc","MBA","MCA","BA","BCom"};
		
		JComboBox c1 = new JComboBox(course);
		c1.setBackground(Color.WHITE);
		c1.setBounds(210, 428, 150, 30);
		contentPane.add(c1);
		
		String clas[] = {"A","B","C","D"};
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name   =textField.getText();
				String age    =textField_1.getText();
				String add    =textField_2.getText();
				String email  =textField_3.getText();
				String fname =textField_5.getText();
				
				String emp    =textField_7.getText();
				textField_7.setEditable(false);
				String phone  =textField_8.getText();
				
				String dept    =(String)c1.getSelectedItem();
				
				 try {
	                    Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/continue2.0","root", "");
	                    PreparedStatement st = (PreparedStatement) connection.prepareStatement("update teacher set name='"+name+"',fathers_name='"+fname+"',age='"+age+"', dob=?,address='"+add+"',phone='"+phone+"',email='"+email+"',department='"+dept+"' where empID='"+emp+"'");
	                    st.setString(1, ((JTextField) date.getDateEditor().getUiComponent()).getText()); 
	                    st.executeUpdate();
	               
	                     JOptionPane.showMessageDialog(btnNewButton, "Teahcer Details Updated Successfully");
	                 
	                } 
				 catch (SQLException sqlException) 
				    {
	                    JOptionPane.showMessageDialog(btnNewButton, "Employee ID already exits");
	                }
				
			}
		});
		//btnNewButton.setBounds(220, 518, 116, 37);
		btnNewButton.setBackground(Color.BLACK);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBounds(210, 518,150,40);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.setBackground(Color.BLACK);
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBounds(516, 518,150,40);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_5.setText("");
			
				textField_7.setText("");
				textField_8.setText("");
				
				c1.setSelectedIndex(0);
			}
		});
		//btnNewButton_1.setBounds(516, 518, 123, 37);
		contentPane.add(btnNewButton_1);
		
		JLabel id1_1 = new JLabel("Age");
		id1_1.setFont(new Font("Serif", Font.BOLD, 20));
		id1_1.setBounds(81, 222, 100, 30);
		contentPane.add(id1_1);
		
		JLabel id1_2 = new JLabel("Address");
		id1_2.setFont(new Font("Serif", Font.BOLD, 20));
		id1_2.setBounds(81, 288, 100, 30);
		contentPane.add(id1_2);
		
		JLabel id1_3 = new JLabel("Email ID");
		id1_3.setFont(new Font("Serif", Font.BOLD, 20));
		id1_3.setBounds(81, 354, 100, 30);
		contentPane.add(id1_3);
		
		JLabel id1_5 = new JLabel("Father's Name");
		id1_5.setFont(new Font("Serif", Font.BOLD, 20));
		id1_5.setBounds(448, 163, 126, 30);
		contentPane.add(id1_5);
		
		JLabel id1_6 = new JLabel("DOB (dd/mm/yyyy)");
		id1_6.setFont(new Font("Serif", Font.BOLD, 20));
		id1_6.setBounds(448, 209, 181, 57);
		contentPane.add(id1_6);
		
		JLabel id1_6_1 = new JLabel("Employee ID");
		id1_6_1.setFont(new Font("Serif", Font.BOLD, 20));
		id1_6_1.setBounds(448, 293, 126, 30);
		contentPane.add(id1_6_1);
		
		JLabel id1_6_1_1 = new JLabel("Phone");
		id1_6_1_1.setFont(new Font("Serif", Font.BOLD, 20));
		id1_6_1_1.setBounds(448, 359, 100, 30);
		contentPane.add(id1_6_1_1);
		
		id1_6_1_2 = new JLabel("Department");
		id1_6_1_2.setFont(new Font("Serif", Font.BOLD, 20));
		id1_6_1_2.setBounds(81, 424, 119, 30);
		contentPane.add(id1_6_1_2);
		
		lblNewLabel = new JLabel("x");
		lblNewLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				new TeacherDetails().setVisible(true);
			}
		});
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 46));
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(937, -15, 36, 52);
		contentPane.add(lblNewLabel);
		
		JLabel lblEnterUsnTo = new JLabel("Enter Employee ID Update Records  ");
		lblEnterUsnTo.setFont(new Font("Serif", Font.BOLD, 20));
		lblEnterUsnTo.setBounds(100, 94, 400, 30);
		contentPane.add(lblEnterUsnTo);
		
		textField_4 = new JTextField();
		textField_4.setBounds(429, 94, 200, 30);
		contentPane.add(textField_4);
		
		
	
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name  =textField.getText();
				String age    =textField_1.getText();
				String add    =textField_2.getText();
				String email  =textField_3.getText();
				String fname =textField_5.getText();
			
				String usn    =textField_7.getText();
				String phone  =textField_8.getText();
				String em_n    =textField_4.getText();
				
				String branch    =(String)c1.getSelectedItem();
			
				 try {
	                    Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/continue2.0","root", "");
	                    PreparedStatement st = (PreparedStatement) connection.prepareStatement("Select * from teacher where empID = '"+em_n+"'");
	                    ResultSet rs = st.executeQuery();
	                    
	                    if(rs.next()){
	                  
	                    textField.setText(rs.getString(2));
	    				textField_1.setText(rs.getString(4));
	    				textField_2.setText(rs.getString(6));
	    				textField_3.setText(rs.getString(8));
	    				textField_5.setText(rs.getString(3));
	    			
	    				textField_7.setText(rs.getString(9));
	    				textField_8.setText(rs.getString(7));
	    				c1.setSelectedItem(rs.getString(10));
	    				((JTextField)date.getDateEditor().getUiComponent()).setText(rs.getString(5));
	    			
	                    } 
	                    else
	                    	JOptionPane.showMessageDialog(btnSearch, "Does not Exists");
	                    
	                    
				 }
				 catch (SQLException sqlException) 
				    {
					 sqlException.printStackTrace();
	                //    JOptionPane.showMessageDialog(btnSearch, "USN already exits");
	                }
			}
		});
		btnSearch.setForeground(Color.WHITE);
		btnSearch.setBackground(new Color(0, 0, 255));
		btnSearch.setBounds(667, 94, 132, 30);
		contentPane.add(btnSearch);
	
		  Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
	}
}
