import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.Icon;
//import javax.swing.Icon;

public class ForgotPassword extends JFrame {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField2;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ForgotPassword frame = new ForgotPassword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ForgotPassword() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("d:\\Users\\Imran\\Desktop\\img\\icon.png"));
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 984, 615);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 425, 637);
		contentPane.add(panel);
		panel.setLayout(null);
		ImageIcon imgpass = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\forgotpassword.jpg").getImage().getScaledInstance(420,615,Image.SCALE_AREA_AVERAGING));
		JLabel lblNewLabel = new JLabel("",imgpass,JLabel.CENTER);
		lblNewLabel.setBounds(-14, 0, 429, 615);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(423, 0, 561, 615);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Forgot Password");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 44));
		lblNewLabel_1.setBounds(169, 86, 322, 63);
		panel_1.add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 32));
		passwordField.setColumns(10);
		passwordField.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(25, 69, 107)));
		passwordField.setBounds(188, 317, 281, 45);
		panel_1.add(passwordField);
		
		textField2 = new JTextField();
		textField2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		textField2.setColumns(10);
		textField2.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(25, 69, 107)));
		textField2.setBounds(188, 222, 281, 45);
		panel_1.add(textField2);
		 
		
		
        ImageIcon imguser = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\user.png").getImage().getScaledInstance(40, 40,Image.SCALE_AREA_AVERAGING));
        JLabel lblUsername = new JLabel("",imguser,JLabel.CENTER);
		
		lblUsername.setForeground(Color.BLACK);
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 31));
		lblUsername.setBackground(Color.BLACK);
		lblUsername.setBounds(96, 208, 63, 63);
		panel_1.add(lblUsername);
		
		ImageIcon imgpass1 = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\pass.png").getImage().getScaledInstance(40, 40, Image.SCALE_AREA_AVERAGING));
	    JLabel lblPassword =new JLabel("",imgpass1,JLabel.CENTER);
		lblPassword.setForeground(Color.BLACK);
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 31));
		lblPassword.setBackground(Color.CYAN);
		lblPassword.setBounds(96, 304, 63, 63);
		panel_1.add(lblPassword);
		
		JLabel lblNewLabel_2 = new JLabel("x");
		lblNewLabel_2.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				new Login().setVisible(true);
			}
		});
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 46));
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setBounds(525, -14, 36, 52);
		panel_1.add(lblNewLabel_2);
		
		ImageIcon imgcross = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\icon.png").getImage().getScaledInstance(50,50, Image.SCALE_SMOOTH));
		
		JLabel lblUsername_1 = new JLabel("",imgcross,JLabel.CENTER);
		lblUsername_1.setForeground(Color.BLACK);
		lblUsername_1.setFont(new Font("Tahoma", Font.PLAIN, 31));
		lblUsername_1.setBackground(Color.BLACK);
		lblUsername_1.setBounds(72, 86, 100, 63);
		panel_1.add(lblUsername_1);
		
		ImageIcon imglogin = new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\reset.png");
		JLabel lblNewLabel_3 = new JLabel("",imglogin,JLabel.CENTER);
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			    String userName = textField2.getText();
                String password = passwordField.getText();
                String password_1 = passwordField_1.getText();
                try {
                    Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/continue2.0","root", "");
                    PreparedStatement st = (PreparedStatement) connection.prepareStatement("Update teacher set pass=? where email=?");
                    st.setString(1, password);
                    st.setString(2, userName);
                    
                    PreparedStatement st1 = (PreparedStatement) connection.prepareStatement("Select email from teacher where email='"+userName+"'");
                    ResultSet rs = st1.executeQuery();
                     if(rs.next())
                     {
                    if(password_1.equals(password) && userName.equals(rs.getString(1)))
                    {
                    	
                        st.executeUpdate();
                        dispose();
                        Login ah = new Login();
                        ah.setTitle("Welcome");
                        ah.setVisible(true);
                        JOptionPane.showMessageDialog(lblNewLabel_3, "Password Changed");
                     
                    }
                     }
                    else
                    	JOptionPane.showMessageDialog(lblNewLabel_3, "Wrong Username & Password");
                } catch (SQLException sqlException) {
                    sqlException.printStackTrace();
                    JOptionPane.showMessageDialog(lblNewLabel_3, "Check Your Database Connection");
                }
			}
		});
		lblNewLabel_3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel_3.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_3.setBounds(232, 497, 181, 52);
		panel_1.add(lblNewLabel_3);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setFont(new Font("Tahoma", Font.PLAIN, 32));
		passwordField_1.setColumns(10);
		passwordField_1.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(25, 69, 107)));
		passwordField_1.setBounds(188, 418, 281, 45);
		panel_1.add(passwordField_1);
		
		ImageIcon imgpass12 = new ImageIcon(new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\pass.png").getImage().getScaledInstance(40, 40, Image.SCALE_AREA_AVERAGING));
	    JLabel lblPassword_1 =new JLabel("",imgpass12,JLabel.CENTER);
		lblPassword_1.setForeground(Color.BLACK);
		lblPassword_1.setFont(new Font("Tahoma", Font.PLAIN, 31));
		lblPassword_1.setBackground(Color.CYAN);
		lblPassword_1.setBounds(96, 400, 63, 63);
		panel_1.add(lblPassword_1);
		
		ImageIcon imgfp = new ImageIcon("d:\\Users\\Imran\\Desktop\\img\\fp1.png");
		
		
		
	     Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
	}
}